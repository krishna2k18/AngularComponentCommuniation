import { Injectable } from '@angular/core';

@Injectable()
export class ProductParameterService {
  showImage: boolean;
  filterBy: string;

  constructor() { }

}
